// All entries are stored with a JS Date-compatible ISO string in `date`.

export function startOfDay(d = new Date()) {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}

export function startOfWeek(d = new Date()) {
  const x = startOfDay(d);
  const day = x.getDay(); // 0 = Sunday
  x.setDate(x.getDate() - day);
  return x;
}

export function startOfMonth(d = new Date()) {
  const x = startOfDay(d);
  x.setDate(1);
  return x;
}

export function startOfPrevMonth(d = new Date()) {
  const x = startOfMonth(d);
  x.setMonth(x.getMonth() - 1);
  return x;
}

export function isSameMonth(dateA, dateB) {
  return (
    dateA.getFullYear() === dateB.getFullYear() &&
    dateA.getMonth() === dateB.getMonth()
  );
}

// Filters a list of entries {date, ...} to those within [from, to)
export function filterByRange(entries, from, to) {
  return entries.filter((e) => {
    const d = new Date(e.date);
    return d >= from && (!to || d < to);
  });
}

export function filterToday(entries) {
  const from = startOfDay();
  const to = new Date(from);
  to.setDate(to.getDate() + 1);
  return filterByRange(entries, from, to);
}

export function filterThisWeek(entries) {
  const from = startOfWeek();
  const to = new Date(from);
  to.setDate(to.getDate() + 7);
  return filterByRange(entries, from, to);
}

export function filterThisMonth(entries) {
  const from = startOfMonth();
  return filterByRange(entries, from, null);
}

export function filterLastMonth(entries) {
  const from = startOfPrevMonth();
  const to = startOfMonth();
  return filterByRange(entries, from, to);
}
