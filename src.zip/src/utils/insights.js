import { filterThisMonth, filterLastMonth } from './dateHelpers';

// Suggested "healthy" spending share per category, as a % of total expenses.
// These are rough personal-finance benchmarks, not hard rules — used only
// to flag categories that are unusually high, not to judge the user.
const CATEGORY_BENCHMARKS = {
  food: 0.20,
  transport: 0.15,
  shopping: 0.10,
  bills: 0.25,
  education: 0.15,
  other: 0.10,
};

export function categoryTotals(expenses) {
  const totals = {};
  for (const e of expenses) {
    totals[e.category] = (totals[e.category] || 0) + Number(e.amount);
  }
  return totals;
}

export function totalOf(entries) {
  return entries.reduce((sum, e) => sum + Number(e.amount), 0);
}

export function topCategory(expenses) {
  const totals = categoryTotals(expenses);
  const entries = Object.entries(totals);
  if (entries.length === 0) return null;
  entries.sort((a, b) => b[1] - a[1]);
  return { category: entries[0][0], amount: entries[0][1] };
}

// Compares this month's category spend to last month's, category by category.
export function monthOverMonth(allExpenses) {
  const thisMonth = categoryTotals(filterThisMonth(allExpenses));
  const lastMonth = categoryTotals(filterLastMonth(allExpenses));
  const categories = new Set([
    ...Object.keys(thisMonth),
    ...Object.keys(lastMonth),
  ]);

  const result = [];
  for (const cat of categories) {
    const curr = thisMonth[cat] || 0;
    const prev = lastMonth[cat] || 0;
    const change = prev === 0 ? (curr > 0 ? 100 : 0) : ((curr - prev) / prev) * 100;
    result.push({ category: cat, current: curr, previous: prev, changePercent: change });
  }
  return result.sort((a, b) => b.current - a.current);
}

// Generates plain-language saving suggestions based on:
// 1. Categories exceeding their benchmark share of total spend
// 2. Categories that jumped significantly vs last month
export function generateSuggestions(allExpenses) {
  const suggestions = [];
  const thisMonthExpenses = filterThisMonth(allExpenses);
  const total = totalOf(thisMonthExpenses);
  if (total === 0) return suggestions;

  const totals = categoryTotals(thisMonthExpenses);

  for (const [category, amount] of Object.entries(totals)) {
    const share = amount / total;
    const benchmark = CATEGORY_BENCHMARKS[category] ?? 0.15;
    if (share > benchmark + 0.05) {
      suggestions.push({
        type: 'high-share',
        category,
        message: `${capitalize(category)} is ${Math.round(share * 100)}% of your spending this month — higher than the typical ${Math.round(benchmark * 100)}%. Consider setting a stricter cap here.`,
      });
    }
  }

  const momChanges = monthOverMonth(allExpenses);
  for (const c of momChanges) {
    if (c.previous > 0 && c.changePercent >= 30) {
      suggestions.push({
        type: 'spike',
        category: c.category,
        message: `${capitalize(c.category)} spending is up ${Math.round(c.changePercent)}% vs last month (Rs. ${c.previous.toFixed(0)} → Rs. ${c.current.toFixed(0)}).`,
      });
    }
  }

  if (suggestions.length === 0) {
    suggestions.push({
      type: 'stable',
      category: null,
      message: 'Spending looks steady across categories this month — no red flags.',
    });
  }

  return suggestions;
}

export function checkBudgetAlerts(allExpenses, budgetLimits) {
  // budgetLimits: { category: number } monthly caps, plus optional "total"
  const alerts = [];
  const thisMonthExpenses = filterThisMonth(allExpenses);
  const totals = categoryTotals(thisMonthExpenses);
  const grandTotal = totalOf(thisMonthExpenses);

  for (const [category, limit] of Object.entries(budgetLimits || {})) {
    if (category === 'total') {
      if (grandTotal > limit) {
        alerts.push({ category: 'total', spent: grandTotal, limit, overBy: grandTotal - limit });
      }
      continue;
    }
    const spent = totals[category] || 0;
    if (spent > limit) {
      alerts.push({ category, spent, limit, overBy: spent - limit });
    }
  }
  return alerts;
}

function capitalize(s) {
  return s.charAt(0).toUpperCase() + s.slice(1);
}
