import { AuthProvider, useAuth } from './hooks/useAuth.jsx';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import './styles.css';

function AppShell() {
  const { user, loading } = useAuth();

  if (loading) return <p className="empty-state">Loading...</p>;
  return user ? <Dashboard /> : <Login />;
}

export default function App() {
  return (
    <AuthProvider>
      <AppShell />
    </AuthProvider>
  );
}
