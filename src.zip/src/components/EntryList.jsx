export default function EntryList({ entries, onDelete, limit = 10 }) {
  const sorted = [...entries]
    .sort((a, b) => new Date(b.date) - new Date(a.date))
    .slice(0, limit);

  if (sorted.length === 0) {
    return <p className="empty-state">No entries yet. Add your first one above.</p>;
  }

  return (
    <ul className="entry-list">
      {sorted.map((e) => (
        <li key={e.id} className={`entry-item ${e.type}`}>
          <div className="entry-main">
            <span className="entry-category">
              {e.type === 'income' ? 'Income' : e.category.charAt(0).toUpperCase() + e.category.slice(1)}
            </span>
            {e.note && <span className="entry-note">{e.note}</span>}
            <span className="entry-date">
              {new Date(e.date).toLocaleDateString()}
            </span>
          </div>
          <div className="entry-actions">
            <span className={`entry-amount ${e.type}`}>
              {e.type === 'income' ? '+' : '-'} Rs. {Number(e.amount).toFixed(2)}
            </span>
            <button className="delete-btn" onClick={() => onDelete(e.id)}>
              ✕
            </button>
          </div>
        </li>
      ))}
    </ul>
  );
}
