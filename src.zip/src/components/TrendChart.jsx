import { Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Tooltip,
  Legend,
} from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, BarElement, Tooltip, Legend);

// Builds totals for the last N months (default 6) from a list of entries.
function monthlyTotals(entries, months = 6) {
  const now = new Date();
  const buckets = [];

  for (let i = months - 1; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    buckets.push({
      key: `${d.getFullYear()}-${d.getMonth()}`,
      label: d.toLocaleString('default', { month: 'short' }),
      total: 0,
    });
  }

  for (const e of entries) {
    const d = new Date(e.date);
    const key = `${d.getFullYear()}-${d.getMonth()}`;
    const bucket = buckets.find((b) => b.key === key);
    if (bucket) bucket.total += Number(e.amount);
  }

  return buckets;
}

export default function TrendChart({ expenses, income }) {
  const expenseBuckets = monthlyTotals(expenses);
  const incomeBuckets = monthlyTotals(income);

  const data = {
    labels: expenseBuckets.map((b) => b.label),
    datasets: [
      {
        label: 'Income',
        data: incomeBuckets.map((b) => b.total),
        backgroundColor: '#10B981',
      },
      {
        label: 'Expenses',
        data: expenseBuckets.map((b) => b.total),
        backgroundColor: '#EF4444',
      },
    ],
  };

  return (
    <div className="chart-card">
      <h3>Monthly Trend (Last 6 Months)</h3>
      <Bar data={data} options={{ plugins: { legend: { position: 'bottom' } } }} />
    </div>
  );
}
