import { Doughnut } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import { categoryTotals } from '../utils/insights';
import { filterThisMonth } from '../utils/dateHelpers';

ChartJS.register(ArcElement, Tooltip, Legend);

const COLORS = {
  food: '#F97316',
  transport: '#3B82F6',
  shopping: '#EC4899',
  bills: '#EF4444',
  education: '#8B5CF6',
  other: '#6B7280',
};

export default function CategoryChart({ expenses }) {
  const monthExpenses = filterThisMonth(expenses);
  const totals = categoryTotals(monthExpenses);
  const labels = Object.keys(totals);

  if (labels.length === 0) {
    return <p className="empty-state">No expenses this month yet.</p>;
  }

  const data = {
    labels: labels.map((l) => l.charAt(0).toUpperCase() + l.slice(1)),
    datasets: [
      {
        data: labels.map((l) => totals[l]),
        backgroundColor: labels.map((l) => COLORS[l] || '#9CA3AF'),
        borderWidth: 0,
      },
    ],
  };

  return (
    <div className="chart-card">
      <h3>Spending by Category (This Month)</h3>
      <Doughnut data={data} options={{ plugins: { legend: { position: 'bottom' } } }} />
    </div>
  );
}
