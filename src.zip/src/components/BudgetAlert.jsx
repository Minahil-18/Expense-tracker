import { useEffect, useState } from 'react';
import { checkBudgetAlerts } from '../utils/insights';

const CATEGORIES = ['food', 'transport', 'shopping', 'bills', 'education', 'other', 'total'];

export default function BudgetAlert({ expenses, budgetLimits, onSave }) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(budgetLimits || {});

  useEffect(() => {
    if (!editing) {
      setDraft(budgetLimits || {});
    }
  }, [budgetLimits, editing]);

  const alerts = checkBudgetAlerts(expenses, budgetLimits);

  const handleSave = (e) => {
    e.preventDefault();
    onSave(draft);
    setEditing(false);
  };

  return (
    <div className="budget-section">
      {alerts.length > 0 && (
        <div className="budget-alerts">
          {alerts.map((a) => (
            <div key={a.category} className="alert-banner">
              ⚠ {a.category === 'total' ? 'Total budget' : a.category.charAt(0).toUpperCase() + a.category.slice(1)}{' '}
              exceeded by Rs. {a.overBy.toFixed(2)} (spent Rs. {a.spent.toFixed(2)} of Rs. {a.limit.toFixed(2)} limit)
            </div>
          ))}
        </div>
      )}

      <button className="link-btn" onClick={() => setEditing(!editing)}>
        {editing ? 'Cancel' : 'Set Budget Limits'}
      </button>

      {editing && (
        <form className="budget-form" onSubmit={handleSave}>
          {CATEGORIES.map((cat) => (
            <div className="form-field" key={cat}>
              <label>{cat === 'total' ? 'Total Monthly Limit' : cat.charAt(0).toUpperCase() + cat.slice(1)} (Rs.)</label>
              <input
                type="number"
                min="0"
                value={draft[cat] || ''}
                onChange={(e) => setDraft({ ...draft, [cat]: Number(e.target.value) })}
              />
            </div>
          ))}
          <button type="submit" className="submit-btn">Save Limits</button>
        </form>
      )}
    </div>
  );
}
