import { useState } from 'react';
import { filterToday, filterThisWeek, filterThisMonth } from '../utils/dateHelpers';
import { totalOf } from '../utils/insights';

const PERIODS = {
  daily: { label: 'Today', fn: filterToday },
  weekly: { label: 'This Week', fn: filterThisWeek },
  monthly: { label: 'This Month', fn: filterThisMonth },
};

export default function SummaryCards({ expenses, income }) {
  const [period, setPeriod] = useState('monthly');
  const filterFn = PERIODS[period].fn;

  const periodExpenses = filterFn(expenses);
  const periodIncome = filterFn(income);

  const totalExpense = totalOf(periodExpenses);
  const totalIncome = totalOf(periodIncome);
  const balance = totalIncome - totalExpense;

  return (
    <div className="summary-section">
      <div className="period-toggle">
        {Object.entries(PERIODS).map(([key, { label }]) => (
          <button
            key={key}
            className={period === key ? 'active' : ''}
            onClick={() => setPeriod(key)}
          >
            {label}
          </button>
        ))}
      </div>

      <div className="summary-cards">
        <div className="card income-card">
          <span className="card-label">Income</span>
          <span className="card-value">Rs. {totalIncome.toFixed(2)}</span>
        </div>
        <div className="card expense-card">
          <span className="card-label">Expenses</span>
          <span className="card-value">Rs. {totalExpense.toFixed(2)}</span>
        </div>
        <div className={`card balance-card ${balance < 0 ? 'negative' : ''}`}>
          <span className="card-label">Balance</span>
          <span className="card-value">Rs. {balance.toFixed(2)}</span>
        </div>
      </div>
    </div>
  );
}
