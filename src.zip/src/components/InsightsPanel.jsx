import { generateSuggestions, topCategory, checkBudgetAlerts } from '../utils/insights';
import { filterThisMonth } from '../utils/dateHelpers';

export default function InsightsPanel({ expenses, budgetLimits }) {
  const monthExpenses = filterThisMonth(expenses);
  const top = topCategory(monthExpenses);
  const suggestions = generateSuggestions(expenses);
  const alerts = checkBudgetAlerts(expenses, budgetLimits);

  return (
    <div className="insights-panel">
      <h3>Smart Insights</h3>

      {alerts.length > 0 && (
        <div className="budget-alerts" style={{ marginBottom: '16px' }}>
          {alerts.map((a) => (
            <div key={a.category} className="alert-banner">
              ⚠ <strong>{a.category === 'total' ? 'Total budget' : a.category.charAt(0).toUpperCase() + a.category.slice(1)}</strong>{' '}
              exceeded by Rs. {a.overBy.toFixed(2)} (spent Rs. {a.spent.toFixed(2)} of Rs. {a.limit.toFixed(2)} limit)
            </div>
          ))}
        </div>
      )}

      {top && (
        <p className="insight-highlight">
          Your highest spending category this month is{' '}
          <strong>{top.category.charAt(0).toUpperCase() + top.category.slice(1)}</strong>{' '}
          at Rs. {top.amount.toFixed(2)}.
        </p>
      )}

      <ul className="suggestion-list">
        {suggestions.map((s, i) => (
          <li key={i} className={`suggestion-item ${s.type}`}>
            {s.message}
          </li>
        ))}
      </ul>
    </div>
  );
}
