import { useEffect, useMemo, useState } from 'react';
import { useAuth } from '../hooks/useAuth.jsx';
import { useEntries } from '../hooks/useEntries';
import { useBudget } from '../hooks/useBudget';
import EntryForm from './EntryForm';
import EntryList from './EntryList';
import CategoryChart from './CategoryChart';
import TrendChart from './TrendChart';
import InsightsPanel from './InsightsPanel';
import BudgetAlert from './BudgetAlert';
import {
  categoryTotals,
  checkBudgetAlerts,
  generateSuggestions,
  monthOverMonth,
  topCategory,
  totalOf,
} from '../utils/insights';
import { filterThisMonth, filterThisWeek, filterToday, filterLastMonth } from '../utils/dateHelpers';

const TABS = [
  { id: 'dashboard', label: 'Dashboard' },
  { id: 'expenses', label: 'Expenses' },
  { id: 'insights', label: 'Insights' },
  { id: 'budget', label: 'Budget' },
];

const PERIODS = {
  all: { label: 'All Time', filter: (items) => items },
  today: { label: 'Today', filter: filterToday },
  week: { label: 'This Week', filter: filterThisWeek },
  month: { label: 'This Month', filter: filterThisMonth },
};

const CATEGORY_FILTERS = ['all', 'expense', 'income', 'food', 'transport', 'shopping', 'bills', 'education', 'other'];

const getUserKeys = (uid) => ({
  monthlyIncome: `spendsense.${uid}.monthly-income`,
  monthlyBudget: `spendsense.${uid}.monthly-budget`,
  currency: `spendsense.${uid}.currency-symbol`,
});

function readStoredNumber(key, fallback) {
  if (typeof window === 'undefined') return fallback;
  const raw = window.localStorage.getItem(key);
  if (raw === null) return fallback;
  const parsed = Number(raw);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function readStoredString(key, fallback) {
  if (typeof window === 'undefined') return fallback;
  const raw = window.localStorage.getItem(key);
  return raw !== null ? raw : fallback;
}

function money(symbol, value) {
  const amount = Number(value || 0);
  return `${symbol}${amount.toLocaleString('en-IN', {
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  })}`;
}

function percent(value) {
  if (!Number.isFinite(value)) return '0%';
  return `${Math.max(0, Math.round(value))}%`;
}

function StatCard({ label, value, helper, tone }) {
  return (
    <article className={`stat-card ${tone || ''}`}>
      <span className="stat-label">{label}</span>
      <strong className="stat-value">{value}</strong>
      {helper && <span className="stat-helper">{helper}</span>}
    </article>
  );
}

export default function Dashboard() {
  const { user, logout } = useAuth();
  const { entries, expenses, income, addEntry, removeEntry, clearEntries, loading } = useEntries();
  const { budgetLimits, loading: budgetLoading, saveBudgetLimits, clearBudgetLimits } = useBudget();

  const [activeTab, setActiveTab] = useState('dashboard');
  const [period, setPeriod] = useState('month');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [monthlyIncome, setMonthlyIncome] = useState(null);
  const [monthlyBudget, setMonthlyBudget] = useState(null);
  const [currencySymbol, setCurrencySymbol] = useState('₹');

  useEffect(() => {
    if (user) {
      const keys = getUserKeys(user.uid);
      setMonthlyIncome(readStoredNumber(keys.monthlyIncome, null));
      setMonthlyBudget(readStoredNumber(keys.monthlyBudget, null));
      setCurrencySymbol(readStoredString(keys.currency, '₹'));
    } else {
      setMonthlyIncome(null);
      setMonthlyBudget(null);
      setCurrencySymbol('₹');
    }
  }, [user]);

  useEffect(() => {
    if (user && monthlyIncome !== null) {
      window.localStorage.setItem(`spendsense.${user.uid}.monthly-income`, String(monthlyIncome));
    }
  }, [user, monthlyIncome]);

  useEffect(() => {
    if (user && monthlyBudget !== null) {
      window.localStorage.setItem(`spendsense.${user.uid}.monthly-budget`, String(monthlyBudget));
    }
  }, [user, monthlyBudget]);

  useEffect(() => {
    if (user && currencySymbol !== null) {
      window.localStorage.setItem(`spendsense.${user.uid}.currency-symbol`, currencySymbol);
    }
  }, [user, currencySymbol]);

  useEffect(() => {
    if (budgetLimits && Object.keys(budgetLimits).length > 0) {
      if (budgetLimits.monthlyIncome !== undefined && budgetLimits.monthlyIncome !== null) {
        setMonthlyIncome(budgetLimits.monthlyIncome);
      }
      if (budgetLimits.total !== undefined && budgetLimits.total !== null) {
        setMonthlyBudget(budgetLimits.total);
      }
      if (budgetLimits.currencySymbol !== undefined && budgetLimits.currencySymbol !== null) {
        setCurrencySymbol(budgetLimits.currencySymbol);
      }
    }
  }, [budgetLimits]);

  const [hasSavedSetup, setHasSavedSetup] = useState(true);

  useEffect(() => {
    if (!budgetLoading && !loading) {
      const hasIncome = monthlyIncome !== null || (budgetLimits && budgetLimits.monthlyIncome !== undefined && budgetLimits.monthlyIncome !== null);
      const hasBudget = monthlyBudget !== null || (budgetLimits && budgetLimits.total !== undefined && budgetLimits.total !== null);

      if (!hasIncome || !hasBudget) {
        setHasSavedSetup(false);
      } else {
        setHasSavedSetup(true);
      }
    }
  }, [budgetLoading, loading, budgetLimits]);

  const needsSetup = !budgetLoading && !loading && !hasSavedSetup;

  const monthExpenses = useMemo(() => filterThisMonth(expenses), [expenses]);
  const monthIncomeEntries = useMemo(() => filterThisMonth(income), [income]);
  const weekExpenses = useMemo(() => filterThisWeek(expenses), [expenses]);
  const todayExpenses = useMemo(() => filterToday(expenses), [expenses]);
  const lastMonthExpenses = useMemo(() => filterLastMonth(expenses), [expenses]);

  const monthExpenseTotal = totalOf(monthExpenses);
  const monthIncomeTotal = totalOf(monthIncomeEntries);
  const weekExpenseTotal = totalOf(weekExpenses);
  const todayExpenseTotal = totalOf(todayExpenses);
  const actualIncomeBaseline = monthIncomeTotal > 0 ? monthIncomeTotal : Number(monthlyIncome || 0);
  const monthlyBudgetTarget = Number(budgetLimits.total || monthlyBudget || monthlyIncome || 0);
  const balance = actualIncomeBaseline - monthExpenseTotal;
  const remainingBudget = monthlyBudgetTarget > 0 ? monthlyBudgetTarget - monthExpenseTotal : balance;
  const budgetUsedPercent = monthlyBudgetTarget > 0 ? Math.min((monthExpenseTotal / monthlyBudgetTarget) * 100, 999) : 0;
  const savingsRate = actualIncomeBaseline > 0 ? (balance / actualIncomeBaseline) * 100 : 0;

  const top = topCategory(monthExpenses);
  const monthCategories = categoryTotals(monthExpenses);
  const categoryRows = Object.entries(monthCategories).sort((a, b) => b[1] - a[1]);
  const suggestions = generateSuggestions(expenses);
  const alerts = checkBudgetAlerts(expenses, budgetLimits);
  const changes = monthOverMonth(expenses);

  const filteredEntries = useMemo(() => {
    const periodEntries = PERIODS[period].filter(entries);
    return periodEntries.filter((entry) => {
      if (categoryFilter === 'all') return true;
      if (categoryFilter === 'expense') return entry.type === 'expense';
      if (categoryFilter === 'income') return entry.type === 'income';
      return entry.type === 'expense' && entry.category === categoryFilter;
    });
  }, [entries, period, categoryFilter]);

  const handleResetAll = async () => {
    const confirmed = window.confirm('This will delete all your entries and budget settings. Continue?');
    if (!confirmed) return;
    await clearEntries();
    await clearBudgetLimits();
    setMonthlyIncome(null);
    setMonthlyBudget(null);
    setCurrencySymbol('₹');
    if (user) {
      window.localStorage.removeItem(`spendsense.${user.uid}.monthly-income`);
      window.localStorage.removeItem(`spendsense.${user.uid}.monthly-budget`);
      window.localStorage.removeItem(`spendsense.${user.uid}.currency-symbol`);
    }
    setHasSavedSetup(false);
  };

  const handleSaveSettings = async (e) => {
    if (e) e.preventDefault();
    await saveBudgetLimits({
      ...budgetLimits,
      total: Number(monthlyBudget || 0),
      monthlyIncome: Number(monthlyIncome || 0),
      currencySymbol: currencySymbol || '₹',
    });
    setHasSavedSetup(true);
  };

  const visibleMonthlyBudget = monthlyBudgetTarget || monthlyBudget;
  const heroShare = top && monthExpenseTotal > 0 ? Math.round((top.amount / monthExpenseTotal) * 100) : 0;

  return (
    <div className="dashboard-shell">
      {needsSetup && (
        <div className="modal-overlay">
          <div className="setup-modal">
            <h2>Welcome to SpendSense! 🚀</h2>
            <p className="subtitle">Let's set up your monthly financial plan to get started.</p>
            <form onSubmit={handleSaveSettings} className="setup-form">
              <div className="form-field">
                <label>What is your Monthly Income?</label>
                <input
                  type="number"
                  min="0"
                  placeholder="e.g. 45000"
                  value={monthlyIncome || ''}
                  onChange={(e) => setMonthlyIncome(Number(e.target.value))}
                  required
                />
              </div>

              <div className="form-field">
                <label>What is your Target Monthly Budget?</label>
                <input
                  type="number"
                  min="0"
                  placeholder="e.g. 30000"
                  value={monthlyBudget || ''}
                  onChange={(e) => setMonthlyBudget(Number(e.target.value))}
                  required
                />
              </div>

              <div className="form-field">
                <label>Select Currency Symbol</label>
                <select
                  value={currencySymbol}
                  onChange={(e) => setCurrencySymbol(e.target.value)}
                >
                  <option value="₹">₹ (INR)</option>
                  <option value="$">$ (USD)</option>
                  <option value="€">€ (EUR)</option>
                  <option value="£">£ (GBP)</option>
                  <option value="¥">¥ (JPY)</option>
                </select>
              </div>

              <button type="submit" className="submit-btn setup-submit-btn">
                Unlock Dashboard
              </button>
            </form>
          </div>
        </div>
      )}
      <div className="dashboard">
        <header className="dashboard-header">
          <div className="brand-block">
            <div className="brand-mark">S</div>
            <div>
              <h1>SpendSense</h1>
              <p className="subtitle">Expense tracker with smart insights</p>
            </div>
          </div>

          <nav className="top-nav" aria-label="Primary navigation">
            {TABS.map((tab) => (
              <button
                key={tab.id}
                type="button"
                className={activeTab === tab.id ? 'active' : ''}
                onClick={() => setActiveTab(tab.id)}
              >
                {tab.label}
              </button>
            ))}
          </nav>

          <div className="header-actions">
            <span className="user-chip">{user?.email}</span>
            <button className="link-btn" onClick={logout}>Log out</button>
          </div>
        </header>

        {loading ? (
          <p className="empty-state">Loading your data...</p>
        ) : (
          <>
            <section className="hero-panel">
              <div className="hero-copy">
                <p className="eyebrow">This month</p>
                <h2>{money(currencySymbol, monthExpenseTotal)}</h2>
                <p className="hero-text">
                  {top
                    ? `${top.category.charAt(0).toUpperCase() + top.category.slice(1)} is your biggest category (${heroShare}% of spending).`
                    : 'Start adding expenses to unlock your spending summary.'}
                </p>

                <div className="hero-progress">
                  <div className="hero-progress-row">
                    <span>Budget {money(currencySymbol, visibleMonthlyBudget || 0)}</span>
                    <strong>{visibleMonthlyBudget > 0 ? `${percent(budgetUsedPercent)} used` : 'Budget not set'}</strong>
                  </div>
                  <div className="progress-track">
                    <div className="progress-fill" style={{ width: `${Math.min(budgetUsedPercent, 100)}%` }} />
                  </div>
                </div>
              </div>

              <div className="hero-metrics">
                <div>
                  <span>Remaining balance</span>
                  <strong>{money(currencySymbol, remainingBudget)}</strong>
                </div>
                <div>
                  <span>Income recorded</span>
                  <strong>{money(currencySymbol, monthIncomeTotal || monthlyIncome)}</strong>
                </div>
                <div>
                  <span>Savings rate</span>
                  <strong>{percent(savingsRate)}</strong>
                </div>
              </div>
            </section>

            <section className="stats-grid">
              <StatCard label="Today" value={money(currencySymbol, todayExpenseTotal)} helper="Spending recorded today" tone="expense" />
              <StatCard label="This week" value={money(currencySymbol, weekExpenseTotal)} helper="Weekly spend report" tone="primary" />
              <StatCard label="Remaining balance" value={money(currencySymbol, remainingBudget)} helper={`Income ${money(currencySymbol, actualIncomeBaseline)}`} tone={balance < 0 ? 'expense' : 'income'} />
              <StatCard label="Top category" value={top ? top.category.charAt(0).toUpperCase() + top.category.slice(1) : 'None'} helper={top ? money(currencySymbol, top.amount) : 'No expenses yet'} tone="neutral" />
            </section>

            <div className="dashboard-layout">
              {activeTab === 'dashboard' && (
                <>
                  <div className="dashboard-grid">
                    <div className="dashboard-col">
                      <EntryForm onAdd={addEntry} />
                      <InsightsPanel expenses={expenses} budgetLimits={budgetLimits} />
                    </div>

                    <div className="dashboard-col">
                      <CategoryChart expenses={expenses} />
                      <TrendChart expenses={expenses} income={income} />
                    </div>
                  </div>

                  <section className="panel-section">
                    <div className="section-header">
                      <div>
                        <h3>Recent expenses</h3>
                        <p>Quick overview of your latest activity.</p>
                      </div>
                      <button className="link-btn" onClick={() => setActiveTab('expenses')}>View all</button>
                    </div>
                    <EntryList entries={entries} onDelete={removeEntry} limit={6} />
                  </section>
                </>
              )}

              {activeTab === 'expenses' && (
                <div className="two-column-layout">
                  <section className="panel-section wide-panel">
                    <div className="section-header">
                      <div>
                        <h3>Expenses</h3>
                        <p>{filteredEntries.length} entries in view</p>
                      </div>
                      <span className="section-meta">{money(currencySymbol, totalOf(filteredEntries))} total</span>
                    </div>

                    <div className="filter-bar">
                      <div className="period-toggle compact">
                        {Object.entries(PERIODS).map(([key, { label }]) => (
                          <button key={key} className={period === key ? 'active' : ''} onClick={() => setPeriod(key)}>
                            {label}
                          </button>
                        ))}
                      </div>

                      <div className="category-pills">
                        {CATEGORY_FILTERS.map((cat) => (
                          <button
                            key={cat}
                            type="button"
                            className={categoryFilter === cat ? 'active' : ''}
                            onClick={() => setCategoryFilter(cat)}
                          >
                            {cat === 'all' ? 'All categories' : cat.charAt(0).toUpperCase() + cat.slice(1)}
                          </button>
                        ))}
                      </div>
                    </div>

                    <EntryList entries={filteredEntries} onDelete={removeEntry} limit={filteredEntries.length} />
                  </section>

                  <aside className="side-column">
                    <EntryForm onAdd={addEntry} />
                    <section className="panel-section mini-summary">
                      <h3>Filtered report</h3>
                      <div className="mini-metrics">
                        <div><span>Income</span><strong>{money(currencySymbol, totalOf(filteredEntries.filter((entry) => entry.type === 'income')))}</strong></div>
                        <div><span>Expenses</span><strong>{money(currencySymbol, totalOf(filteredEntries.filter((entry) => entry.type === 'expense')))}</strong></div>
                        <div><span>Net</span><strong>{money(currencySymbol, totalOf(filteredEntries.filter((entry) => entry.type === 'income')) - totalOf(filteredEntries.filter((entry) => entry.type === 'expense')))}</strong></div>
                      </div>
                    </section>
                  </aside>
                </div>
              )}

              {activeTab === 'insights' && (
                <div className="two-column-layout">
                  <section className="panel-section wide-panel">
                    <div className="section-header">
                      <div>
                        <h3>Smart insights</h3>
                        <p>Automatic analysis of your spending habits and where you can save.</p>
                      </div>
                    </div>

                    <div className="insight-grid">
                      <StatCard label="Last month change" value={percent(monthOverMonth(expenses)[0]?.changePercent || 0)} helper="Largest category movement" tone="primary" />
                      <StatCard label="Alerts" value={`${alerts.length}`} helper="Active budget warnings" tone={alerts.length ? 'expense' : 'income'} />
                      <StatCard label="Stable habits" value={suggestions.some((item) => item.type === 'stable') ? 'Yes' : 'No'} helper="Rule-based financial check" tone="neutral" />
                    </div>

                    <InsightsPanel expenses={expenses} budgetLimits={budgetLimits} />
                  </section>

                  <aside className="side-column">
                    <CategoryChart expenses={expenses} />
                    <TrendChart expenses={expenses} income={income} />
                  </aside>
                </div>
              )}

              {activeTab === 'budget' && (
                <div className="two-column-layout">
                  <section className="panel-section wide-panel">
                    <div className="section-header">
                      <div>
                        <h3>Budget & income</h3>
                        <p>Set the financial guardrails for your monthly plan.</p>
                      </div>
                    </div>

                    <form className="budget-settings-grid" onSubmit={handleSaveSettings}>
                      <div className="form-field">
                        <label>Monthly income</label>
                        <input type="number" min="0" value={monthlyIncome} onChange={(e) => setMonthlyIncome(Number(e.target.value))} />
                      </div>
                      <div className="form-field">
                        <label>Monthly budget limit</label>
                        <input type="number" min="0" value={monthlyBudget} onChange={(e) => setMonthlyBudget(Number(e.target.value))} />
                      </div>
                      <div className="form-field">
                        <label>Currency symbol</label>
                        <input type="text" maxLength={3} value={currencySymbol} onChange={(e) => setCurrencySymbol(e.target.value || '₹')} />
                      </div>
                      <button className="submit-btn" type="submit">Save settings</button>
                    </form>

                    <div className="panel-section inner-panel">
                      <BudgetAlert expenses={expenses} budgetLimits={budgetLimits} onSave={saveBudgetLimits} />
                    </div>
                  </section>

                  <aside className="side-column">
                    <section className="panel-section mini-summary">
                      <h3>Budget snapshot</h3>
                      <div className="mini-metrics">
                        <div><span>This month spent</span><strong>{money(currencySymbol, monthExpenseTotal)}</strong></div>
                        <div><span>Budget left</span><strong>{money(currencySymbol, remainingBudget)}</strong></div>
                        <div><span>Budget used</span><strong>{percent(budgetUsedPercent)}</strong></div>
                      </div>
                    </section>

                    <section className="panel-section danger-panel">
                      <h3>Reset data</h3>
                      <p>Clear your entries and restore the sample defaults.</p>
                      <button className="danger-btn" type="button" onClick={handleResetAll}>Reset everything</button>
                    </section>
                  </aside>
                </div>
              )}
            </div>

            <section className="footer-note">
              {suggestions.length > 0 && <span>{suggestions[0].message}</span>}
              <span>Your data is saved locally in your browser and in Firebase.</span>
            </section>
          </>
        )}
      </div>
    </div>
  );
}
