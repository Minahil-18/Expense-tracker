import { useEffect, useState } from 'react';
import { doc, setDoc, onSnapshot, deleteDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from './useAuth';

// One document per user at budgets/{uid}, shape: { food: 5000, transport: 2000, total: 20000, ... }

export function useBudget() {
  const { user } = useAuth();
  const [budgetLimits, setBudgetLimits] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      setBudgetLimits({});
      setLoading(false);
      return;
    }
    const ref = doc(db, 'budgets', user.uid);
    const unsub = onSnapshot(ref, (snap) => {
      setBudgetLimits(snap.exists() ? snap.data() : {});
      setLoading(false);
    });
    return unsub;
  }, [user]);

  const saveBudgetLimits = async (limits) => {
    if (!user) return;
    await setDoc(doc(db, 'budgets', user.uid), limits, { merge: true });
  };

  const clearBudgetLimits = async () => {
    if (!user) return;
    await deleteDoc(doc(db, 'budgets', user.uid));
  };

  return { budgetLimits, loading, saveBudgetLimits, clearBudgetLimits };
}
