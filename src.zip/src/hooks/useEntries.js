import { useEffect, useState } from 'react';
import {
  collection,
  addDoc,
  deleteDoc,
  doc,
  onSnapshot,
  query,
  where,
  orderBy,
} from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from './useAuth';


export function useEntries() {
  const { user } = useAuth();
  const [entries, setEntries] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      setEntries([]);
      setLoading(false);
      return;
    }
    const q = query(
      collection(db, 'entries'),
      where('userId', '==', user.uid)
    );
    const unsub = onSnapshot(q, (snap) => {
      const fetchedEntries = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
      // Sort in-memory: date descending (latest first)
      fetchedEntries.sort((a, b) => (b.date || '').localeCompare(a.date || ''));
      setEntries(fetchedEntries);
      setLoading(false);
    }, (error) => {
      console.error("Firestore onSnapshot error:", error);
      setLoading(false);
    });
    return unsub;
  }, [user]);

  const addEntry = async (entry) => {
    if (!user) return;
    await addDoc(collection(db, 'entries'), {
      userId: user.uid,
      ...entry,
    });
  };

  const removeEntry = async (id) => {
    await deleteDoc(doc(db, 'entries', id));
  };

  const clearEntries = async () => {
    await Promise.all(entries.map((entry) => deleteDoc(doc(db, 'entries', entry.id))));
  };

  const expenses = entries.filter((e) => e.type === 'expense');
  const income = entries.filter((e) => e.type === 'income');

  return { entries, expenses, income, loading, addEntry, removeEntry, clearEntries };
}
